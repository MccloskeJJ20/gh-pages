let vid1;
let vid2;
let vid3;
function setup() {
  vid1 = createVideo(
    ['flowers_small.mp4'],
    vidLoad
  );
  vid1.size(100, 100);
  vid2 = createVideo(
    ['batman.webm'],
    vidLoad
  );
  vid2.size(100, 100);
  vid3 = createVideo(
    ['cat.ogg'],
    vidLoad
  );
  vid3.size(100, 100);
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function vidLoad() {
  vid1.loop();
  vid1.volume(0);
  vid2.loop();
  vid2.volume(0);
  vid3.loop();
  vid3.volume(0);
}