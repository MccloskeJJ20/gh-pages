let img1;
let img2;
function setup() {
  createCanvas(400, 400);
}
function draw() { 
  background(220);
  textWidth ("car")
  fill (255, 204, 0)
  stroke(51)
  textFont('Gotham', 40);
  text('car', 10, 60);
  textFont("Roboto", 40);
  text('racecar', 40, 200);
  image(img2, 100, mouseY, 100, 100)  
  image(img1, mouseX, 100, 100, 100)
}
function preload() {
  // preload() runs once
  img1 = loadImage("cat.jpg");
  img2 = loadImage("Cat2.png")

}
