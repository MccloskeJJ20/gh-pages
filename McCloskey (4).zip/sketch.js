let capture;
let mic;
let osc;
function setup() {
  capture = createCapture(VIDEO);
  capture.size(320, 240);
  osc = new p5.Oscillator();
  osc.setType('sine');
  osc.freq(50);
  osc.amp(50);
  osc.start();
  print(osc)

  mic = new p5.AudioIn();
  mic.start();
  
  createCanvas(400, 400);
  soundFile.setVolume(0.1);
  soundFile.loop();
}

function draw() {
  let vol = mic.getLevel();
  background(220);
  image(capture, 0, 0, 100, 100);
  filter(INVERT);
  circle(200, 200, vol*100);
}


function preload() {
  soundFormats("wav");
  soundFile = loadSound("dundundun.wav");
}

function keyTyped() {
  if (key == 'p') {
    soundFile.pause();
  }
}